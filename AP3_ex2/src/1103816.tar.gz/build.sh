#!/bin/bash

javac *.java
